CREATE TABLE role (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE "user" (
    id SERIAL PRIMARY KEY,
    login VARCHAR(100) NOT NULL,
    password VARCHAR(500) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    role_id INTEGER REFERENCES role(id)
);

CREATE TABLE tea (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    path_img VARCHAR(255),
    info TEXT
);



INSERT INTO role (name) VALUES ('Пользователь');
INSERT INTO role (name) VALUES ('Администратор');
