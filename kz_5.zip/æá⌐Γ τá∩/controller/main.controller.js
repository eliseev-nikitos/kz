const path = require('path');
const ejs = require('ejs');

const teaModel = require('../model/tea.model');


class MainController{

    async getMain(req, res) {
        const template = path.join(__dirname, '..', 'view', 'main.ejs');

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role });

        res.send(html);
    }

    async getAuth(req, res) {
        const template = path.join(__dirname, '..', 'view', 'auth.ejs');

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role });

        res.send(html);
    }

    async getRegistration(req, res) {
        const template = path.join(__dirname, '..', 'view', 'registration.ejs');

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role });

        res.send(html);
    }

    async getBlog(req, res) {
        const template = path.join(__dirname, '..', 'view', 'blog.ejs');

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role });

        res.send(html);
    }

    async getCatalog(req, res) {
        const template = path.join(__dirname, '..', 'view', 'catalog.ejs');

        const role = req.user.role;

        const teas = await teaModel.getAll();

        let html = await ejs.renderFile(template, { role, teas });

        res.send(html);
    }

    async getInstruction(req, res) {
        const template = path.join(__dirname, '..', 'view', 'instruction.ejs');

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role });

        res.send(html);
    }

    async getProduct(req, res) {
        const template = path.join(__dirname, '..', 'view', 'product.ejs');

        const id = req.params.id;

        const tea = await teaModel.getOneById(id);

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role, tea });

        res.send(html);
    }

    async getStat(req, res) {
        const template = path.join(__dirname, '..', 'view', 'stat.ejs');

        const role = req.user.role;
        let html = await ejs.renderFile(template, { role });

        res.send(html);
    }

    async logout(req, res) {
        res.clearCookie('token');
        res.redirect('/');
    }

}

module.exports = new MainController();